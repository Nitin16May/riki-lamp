#include "touch.h"
#include <Arduino.h>

void touchSetup() {
    Serial.println("[Touch] Module Loaded");
}

void touchLoop() {

}