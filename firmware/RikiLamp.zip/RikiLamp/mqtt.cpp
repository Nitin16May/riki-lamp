#include "mqtt.h"
#include <Arduino.h>

void mqttSetup() {
    Serial.println("[MQTT] Module Loaded");
}

void mqttLoop() {

}