#include "riki_network.h"

#include <Arduino.h>
#include <WiFi.h>

RiKiNetwork rikiNetwork;

void RiKiNetwork::begin() {
    startAccessPoint();
}

void RiKiNetwork::loop() {
}
void RiKiNetwork::startAccessPoint() {

    WiFi.mode(WIFI_MODE_AP);

    delay(500);

    bool ok = WiFi.softAP(
        "RiKiLamp-Setup",
        nullptr,
        6,
        false,
        4
    );

    Serial.printf("AP Started: %s\n", ok ? "YES" : "NO");

    Serial.print("AP SSID: ");
    Serial.println(WiFi.softAPSSID());

    Serial.print("AP IP: ");
    Serial.println(WiFi.softAPIP());

    Serial.print("AP MAC: ");
    Serial.println(WiFi.softAPmacAddress());
}