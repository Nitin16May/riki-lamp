#pragma once

void touchSetup();
void touchLoop();
