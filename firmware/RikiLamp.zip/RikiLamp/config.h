#pragma once

#define DEVICE_NAME "RiKi Lamp"
