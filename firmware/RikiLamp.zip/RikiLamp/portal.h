#pragma once

class PortalManager {

public:

    void begin();

    void loop();

};

extern PortalManager portal;