#pragma once

void ledSetup();
void ledLoop();
