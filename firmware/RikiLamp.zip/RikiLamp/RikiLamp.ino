#include "storage.h"
#include "riki_network.h"
#include "portal.h"

void setup() {

    Serial.begin(115200);

    while (!Serial) {
        delay(10);
    }

    storage.begin();

    Serial.println();
    Serial.println("==========================");
    Serial.println("      RiKi Lamp");
    Serial.println("==========================");

    if (storage.hasWiFi()) {

        Serial.println("✓ WiFi credentials found");
        Serial.print("SSID: ");
        Serial.println(storage.getSSID());

    } else {

        Serial.println("No WiFi configured.");
        rikiNetwork.begin();
        portal.begin();
    }
}

void loop() {
    rikiNetwork.loop();
    portal.loop();
}