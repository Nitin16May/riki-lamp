#include "portal.h"

#include <Arduino.h>
#include <WiFi.h>
#include <WebServer.h>
#include <DNSServer.h>
#include <ArduinoJson.h>

WebServer server(80);
DNSServer dnsServer;

PortalManager portal;

constexpr byte DNS_PORT = 53;

// ---------- Global State ----------

bool scanRunning = false;
bool scanFinished = false;
int scanResultCount = 0;

String selectedSSID = "";
String selectedPassword = "";

// ---------- HTML ----------

const char INDEX_HTML[] PROGMEM = R"rawliteral(

<!DOCTYPE html>
<html>

<head>

<meta charset="UTF-8">

<meta
name="viewport"
content="width=device-width, initial-scale=1.0">

<title>RiKi Lamp</title>

<style>

*{
margin:0;
padding:0;
box-sizing:border-box;
font-family:
-apple-system,
BlinkMacSystemFont,
"Segoe UI",
Roboto,
Arial,
sans-serif;
}

body{

background:#0E1117;

color:white;

display:flex;

justify-content:center;

align-items:center;

height:100vh;

padding:18px;

}

.card{

width:390px;

background:#171B24;

border-radius:24px;

padding:32px;

box-shadow:
0 20px 80px rgba(0,0,0,.45);

animation:fade .5s ease;

}

@keyframes fade{

from{

opacity:0;
transform:translateY(18px);

}

to{

opacity:1;
transform:none;

}

}

.logo{

font-size:60px;

text-align:center;

margin-bottom:8px;

animation:breathe 3s infinite;

}

@keyframes breathe{

0%{
transform:scale(1);
}

50%{
transform:scale(1.08);
}

100%{
transform:scale(1);
}

}

h1{

text-align:center;

font-size:30px;

margin-bottom:10px;

}

.subtitle{

text-align:center;

color:#9AA5B1;

line-height:1.6;

font-size:15px;

margin-bottom:26px;

}

.status{

display:flex;

align-items:center;

justify-content:center;

gap:10px;

margin-bottom:24px;

font-size:15px;

color:#C7CED8;

}

.spinner{

width:18px;

height:18px;

border-radius:50%;

border:3px solid #3D4654;

border-top:3px solid white;

animation:spin .8s linear infinite;

}

@keyframes spin{

to{

transform:rotate(360deg);

}

}

label{

display:block;

margin-bottom:8px;

font-size:14px;

font-weight:600;

}

select,
input{

width:100%;

padding:14px;

background:#232A36;

border:none;

outline:none;

color:white;

font-size:15px;

border-radius:12px;

margin-bottom:18px;

}

.password{

position:relative;

}

.eye{

position:absolute;

right:15px;

top:15px;

cursor:pointer;

user-select:none;

}

button{

width:100%;

padding:15px;

border:none;

border-radius:14px;

background:white;

color:#111;

font-size:16px;

font-weight:700;

cursor:pointer;

transition:.25s;

}

button:hover{

transform:translateY(-2px);

}

.footer{

margin-top:24px;

text-align:center;

font-size:13px;

color:#7B8695;

}

</style>

</head>

<body>

<div class="card">

<div class="logo">

❤️

</div>

<h1>

RiKi Lamp

</h1>

<div class="subtitle">

A little light for every distance.

<br><br>

Built with ❤️ for Chakri & Nikki

</div>

<div class="status">

<div class="spinner"></div>

<div id="status">

Scanning nearby Wi-Fi...

</div>

</div>
<label>

Wi-Fi Network

</label>

<select id="wifi">

<option>

Scanning...

</option>

</select>

<label>

Password

</label>

<div class="password">

<input
id="password"
type="password"
placeholder="Enter Wi-Fi Password">

<div
class="eye"
onclick="togglePassword()">

👁

</div>

</div>

<button
id="connect">

Connect Lamp

</button>

<div class="footer">

Firmware v1.0.0

</div>

</div>

<script>

const wifi=document.getElementById("wifi");
const statusText=document.getElementById("status");
const connectButton=document.getElementById("connect");

window.onload=()=>{

    scanWifi();

};

async function scanWifi(){

    statusText.innerHTML="Scanning nearby Wi-Fi...";

    wifi.innerHTML="<option>Scanning...</option>";

    try{

        const res=await fetch("/scan");

        const list=await res.json();

        wifi.innerHTML="";

        if(list.length===0){

            wifi.innerHTML="<option>No Wi-Fi Found</option>";

            statusText.innerHTML="No nearby Wi-Fi found.";

            return;

        }

        list.forEach(item=>{

            const option=document.createElement("option");

            option.value=item.ssid;

            option.innerHTML=item.icon+" "+item.ssid;

            wifi.appendChild(option);

        });

        statusText.innerHTML=list.length+" network(s) found";

    }

    catch(e){

        wifi.innerHTML="<option>Scan Failed</option>";

        statusText.innerHTML="Unable to scan.";

    }

}

function togglePassword(){

    const p=document.getElementById("password");

    if(p.type==="password")
        p.type="text";
    else
        p.type="password";

}

connectButton.onclick=async()=>{

    connectButton.disabled=true;

    connectButton.innerHTML="Connecting...";

    statusText.innerHTML="Connecting to Wi-Fi...";

    const response=await fetch("/connect",{

        method:"POST",

        headers:{
            "Content-Type":"application/json"
        },

        body:JSON.stringify({

            ssid:wifi.value,

            password:document.getElementById("password").value

        })

    });

    const result=await response.json();

    connectButton.disabled=false;

    connectButton.innerHTML="Connect Lamp";

    statusText.innerHTML=result.message;

    if(result.success){

        document.querySelector(".card").innerHTML=`

        <div class="logo">💖</div>

        <h1>Connected!</h1>

        <div class="subtitle">

        RiKi Lamp is restarting...

        <br><br>

        See you on your home Wi-Fi.

        </div>

        `;

    }

}

</script>

</body>

</html>

)rawliteral";
// ---------- HTTP Handlers ----------

void handleRoot() {

    server.send_P(
        200,
        "text/html",
        INDEX_HTML
    );

}

// ---------- Wi-Fi Scan ----------

void handleScan() {

    Serial.println();
    Serial.println("Starting Wi-Fi Scan...");

    WiFi.mode(WIFI_AP_STA);

    int count = WiFi.scanNetworks();

    JsonDocument doc;

    JsonArray array = doc.to<JsonArray>();

    for (int i = 0; i < count; i++) {

        JsonObject network = array.add<JsonObject>();

        network["ssid"] = WiFi.SSID(i);

        network["rssi"] = WiFi.RSSI(i);

        if (WiFi.RSSI(i) >= -55)
            network["icon"] = "🟢";

        else if (WiFi.RSSI(i) >= -70)
            network["icon"] = "🟡";

        else
            network["icon"] = "🔴";

    }

    String response;

    serializeJson(doc, response);

    WiFi.scanDelete();

    server.send(
        200,
        "application/json",
        response
    );

}

// ---------- Connect ----------

void handleConnect() {

    if (!server.hasArg("plain")) {

        server.send(
            400,
            "application/json",
            "{\"success\":false,\"message\":\"Missing Data\"}"
        );

        return;

    }

    JsonDocument doc;

    DeserializationError err =
        deserializeJson(doc, server.arg("plain"));

    if (err) {

        server.send(
            400,
            "application/json",
            "{\"success\":false,\"message\":\"Invalid JSON\"}"
        );

        return;

    }

    selectedSSID =
        doc["ssid"].as<String>();

    selectedPassword =
        doc["password"].as<String>();

    Serial.println();
    Serial.println("====== Connect Request ======");

    Serial.print("SSID : ");
    Serial.println(selectedSSID);

    Serial.print("PASS : ");
    Serial.println(selectedPassword);

    JsonDocument reply;

    reply["success"] = true;

    reply["message"] =
        "Connecting to " + selectedSSID + "...";

    String output;

    serializeJson(reply, output);

    server.send(
        200,
        "application/json",
        output
    );

}
