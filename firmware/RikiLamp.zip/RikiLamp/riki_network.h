#pragma once

class RiKiNetwork {
public:
    void begin();
    void loop();

private:
    void startAccessPoint();
};

extern RiKiNetwork rikiNetwork;