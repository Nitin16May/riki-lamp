#include "led.h"
#include <Arduino.h>

void ledSetup() {
    Serial.println("[LED] Module Loaded");
}

void ledLoop() {

}