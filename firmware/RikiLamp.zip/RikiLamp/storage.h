#pragma once

#include <Arduino.h>
#include <Preferences.h>

class StorageManager {
public:
    void begin();

    bool hasWiFi();

    void saveWiFi(const String& ssid, const String& password);

    String getSSID();

    String getPassword();

    void clear();

private:
    Preferences prefs;
};

extern StorageManager storage;
