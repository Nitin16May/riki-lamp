#include "storage.h"

StorageManager storage;

void StorageManager::begin() {
    prefs.begin("riki", false);
}

bool StorageManager::hasWiFi() {
    return prefs.isKey("ssid");
}

void StorageManager::saveWiFi(const String& ssid, const String& password) {
    prefs.putString("ssid", ssid);
    prefs.putString("pass", password);
}

String StorageManager::getSSID() {
    return prefs.getString("ssid", "");
}

String StorageManager::getPassword() {
    return prefs.getString("pass", "");
}

void StorageManager::clear() {
    prefs.clear();
}